package com.example.tasks

import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.serialization.kotlinx.json.json
import io.ktor.server.application.Application
import io.ktor.server.application.call
import io.ktor.server.application.install
import io.ktor.server.application.log
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.plugins.BadRequestException
import io.ktor.server.plugins.CannotTransformContentToTypeException
import io.ktor.server.plugins.UnsupportedMediaTypeException
import io.ktor.server.plugins.calllogging.CallLogging
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.openapi.openAPI
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.plugins.swagger.swaggerUI
import io.ktor.server.request.receive
import io.ktor.server.response.header
import io.ktor.server.response.respond
import io.ktor.server.routing.delete
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.routing
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import org.slf4j.event.Level

private val allowedStatuses = setOf("todo", "in_progress", "done")

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0", module = Application::module)
        .start(wait = true)
}

fun Application.module() {
    install(ContentNegotiation) {
        json(Json {
            prettyPrint = true
            ignoreUnknownKeys = true
        })
    }

    install(CallLogging) {
        level = Level.INFO
    }

    install(StatusPages) {
        exception<BadRequestException> { call, _ ->
            call.respond(HttpStatusCode.BadRequest, ErrorResponse("Некорректный запрос"))
        }

        exception<SerializationException> { call, _ ->
            call.respond(HttpStatusCode.BadRequest, ErrorResponse("Некорректный JSON"))
        }

        exception<UnsupportedMediaTypeException> { call, _ ->
            call.respond(
                HttpStatusCode.UnsupportedMediaType,
                ErrorResponse("Ожидается Content-Type: application/json"),
            )
        }

        exception<CannotTransformContentToTypeException> { call, _ ->
            call.respond(
                HttpStatusCode.UnsupportedMediaType,
                ErrorResponse("Ожидается Content-Type: application/json"),
            )
        }

        exception<Throwable> { call, cause ->
            call.application.log.error("Внутренняя ошибка", cause)
            call.respond(HttpStatusCode.InternalServerError, ErrorResponse("Внутренняя ошибка сервера"))
        }
    }

    routing {
        swaggerUI(path = "swagger", swaggerFile = "openapi/documentation.yaml")
        openAPI(path = "openapi", swaggerFile = "openapi/documentation.yaml") {
            outputPath = "build/openapi"
        }

        get("/") {
            call.respond(mapOf("service" to "Tasks API"))
        }

        get("/tasks") {
            val status = call.request.queryParameters["status"]
            val limitParameter = call.request.queryParameters["limit"]
            val limit = limitParameter?.toIntOrNull()

            if (status != null && !allowedStatuses.contains(status)) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Неизвестный статус: $status"))
                return@get
            }

            if (limitParameter != null && (limit == null || limit < 1)) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Параметр limit должен быть положительным числом"))
                return@get
            }

            call.respond(TaskRepository.findAll(status, limit))
        }

        get("/tasks/{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id == null) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Некорректный id задачи"))
                return@get
            }

            val task = TaskRepository.findById(id)
            if (task == null) {
                call.respond(HttpStatusCode.NotFound, ErrorResponse("Задача с id=$id не найдена"))
            } else {
                call.respond(task)
            }
        }

        post("/tasks") {
            val request = call.receive<CreateTaskRequest>()

            if (request.title.isBlank()) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Поле title не может быть пустым"))
                return@post
            }

            if (!allowedStatuses.contains(request.status)) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Неизвестный статус: ${request.status}"))
                return@post
            }

            val task = TaskRepository.create(request)
            call.response.header(HttpHeaders.Location, "/tasks/${task.id}")
            call.respond(HttpStatusCode.Created, task)
        }

        delete("/tasks/{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id == null) {
                call.respond(HttpStatusCode.BadRequest, ErrorResponse("Некорректный id задачи"))
                return@delete
            }

            if (TaskRepository.delete(id)) {
                call.respond(HttpStatusCode.NoContent)
            } else {
                call.respond(HttpStatusCode.NotFound, ErrorResponse("Задача с id=$id не найдена"))
            }
        }
    }
}
