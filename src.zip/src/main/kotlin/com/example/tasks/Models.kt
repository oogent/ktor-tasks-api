package com.example.tasks

import kotlinx.serialization.Serializable

@Serializable
data class Task(
    val id: Int,
    val title: String,
    val description: String? = null,
    val status: String = "todo",
    val createdAt: String,
)

@Serializable
data class CreateTaskRequest(
    val title: String,
    val description: String? = null,
    val status: String = "todo",
)

@Serializable
data class ErrorResponse(
    val error: String,
)
