package com.example.tasks

import java.time.Instant

object TaskRepository {
    private val tasks = mutableListOf<Task>()
    private var nextId = 1

    @Synchronized
    fun findAll(status: String?, limit: Int?): List<Task> {
        val result = if (status == null) {
            tasks.toList()
        } else {
            tasks.filter { it.status == status }
        }
        return if (limit == null) result else result.take(limit)
    }

    @Synchronized
    fun findById(id: Int): Task? = tasks.firstOrNull { it.id == id }

    @Synchronized
    fun create(request: CreateTaskRequest): Task {
        val task = Task(
            id = nextId++,
            title = request.title.trim(),
            description = request.description?.trim()?.ifEmpty { null },
            status = request.status,
            createdAt = Instant.now().toString(),
        )
        tasks.add(task)
        return task
    }

    @Synchronized
    fun delete(id: Int): Boolean = tasks.removeAll { it.id == id }

    @Synchronized
    fun clear() {
        tasks.clear()
        nextId = 1
    }
}
