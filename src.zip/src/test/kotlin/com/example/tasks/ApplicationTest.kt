package com.example.tasks

import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import io.ktor.server.testing.testApplication
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ApplicationTest {

    @BeforeTest
    fun clearRepository() {
        TaskRepository.clear()
    }

    @Test
    fun `tasks list is empty`() = testApplication {
        application { module() }

        val response = client.get("/tasks")

        assertEquals(HttpStatusCode.OK, response.status)
        assertEquals("[]", response.bodyAsText().trim())
    }

    @Test
    fun `create task returns 201`() = testApplication {
        application { module() }

        val response = client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody("""{"title":"Тестовая задача","description":"Проверка"}""")
        }

        assertEquals(HttpStatusCode.Created, response.status)
        assertEquals("/tasks/1", response.headers[HttpHeaders.Location])
        assertTrue(response.bodyAsText().contains("Тестовая задача"))
    }

    @Test
    fun `get task by id returns 200`() = testApplication {
        application { module() }

        client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody("""{"title":"Задача"}""")
        }

        val response = client.get("/tasks/1")

        assertEquals(HttpStatusCode.OK, response.status)
        assertTrue(response.bodyAsText().contains("\"id\": 1"))
    }

    @Test
    fun `delete task returns 204`() = testApplication {
        application { module() }

        client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody("""{"title":"Удаляемая задача"}""")
        }

        val response = client.delete("/tasks/1")

        assertEquals(HttpStatusCode.NoContent, response.status)
        assertEquals("", response.bodyAsText())
        assertEquals(HttpStatusCode.NotFound, client.get("/tasks/1").status)
    }

    @Test
    fun `missing task returns 404`() = testApplication {
        application { module() }

        val response = client.get("/tasks/999")

        assertEquals(HttpStatusCode.NotFound, response.status)
        assertTrue(response.bodyAsText().contains("не найдена"))
    }

    @Test
    fun `invalid id returns 400`() = testApplication {
        application { module() }

        val response = client.get("/tasks/abc")

        assertEquals(HttpStatusCode.BadRequest, response.status)
    }

    @Test
    fun `empty title returns 400`() = testApplication {
        application { module() }

        val response = client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody("""{"title":" "}""")
        }

        assertEquals(HttpStatusCode.BadRequest, response.status)
    }

    @Test
    fun `wrong content type returns 415`() = testApplication {
        application { module() }

        val response = client.post("/tasks") {
            contentType(ContentType.Text.Plain)
            setBody("""{"title":"Задача"}""")
        }

        assertEquals(HttpStatusCode.UnsupportedMediaType, response.status)
    }

    @Test
    fun `malformed json returns 400`() = testApplication {
        application { module() }

        val response = client.post("/tasks") {
            contentType(ContentType.Application.Json)
            setBody("""{"title": }""")
        }

        assertEquals(HttpStatusCode.BadRequest, response.status)
    }

    @Test
    fun `swagger and openapi are available`() = testApplication {
        application { module() }

        assertEquals(HttpStatusCode.OK, client.get("/swagger").status)
        assertEquals(HttpStatusCode.OK, client.get("/openapi").status)
    }
}
